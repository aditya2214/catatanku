<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div style="margin:10px; position:fixed; left:82%; top:10%;" class="col-xl-2 fixed-top">
            <div class="card">
                <div class="card-header">
                    <form target="_blank" action="<?php echo e(url ('print')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="">Initial Parameter </label>
                            <input type="date" name="initial_prameter" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Final Parameter </label>
                            <input type="date" name="final_parameter" class="form-control">
                        </div>
                        <br>
                        <button class="btn btn-success btn-sm">Print Report</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-12`">
            <div class="card">
                <div class="card-header">Catatanku SPA</div>

                <div class="card-body">
                    
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home-index', [])->html();
} elseif ($_instance->childHasBeenRendered('qkmI7f2')) {
    $componentId = $_instance->getRenderedChildComponentId('qkmI7f2');
    $componentTag = $_instance->getRenderedChildComponentTagName('qkmI7f2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qkmI7f2');
} else {
    $response = \Livewire\Livewire::mount('home-index', []);
    $html = $response->html();
    $_instance->logRenderedChild('qkmI7f2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:home-index>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catatanku3\resources\views/home.blade.php ENDPATH**/ ?>