<div>
    <?php if($order): ?>
        <button wire:click="back" class="btn btn-danger btn-sm">Kembali</button>
        <hr>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order-index', [])->html();
} elseif ($_instance->childHasBeenRendered('TFkPS90')) {
    $componentId = $_instance->getRenderedChildComponentId('TFkPS90');
    $componentTag = $_instance->getRenderedChildComponentTagName('TFkPS90');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TFkPS90');
} else {
    $response = \Livewire\Livewire::mount('order-index', []);
    $html = $response->html();
    $_instance->logRenderedChild('TFkPS90', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:order-index>
    <?php else: ?>
        <div class="row">
            <div class="col-md-4">
                <?php if($statusUpdate): ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('update-pemesan', [])->html();
} elseif ($_instance->childHasBeenRendered('lu7PwHW')) {
    $componentId = $_instance->getRenderedChildComponentId('lu7PwHW');
    $componentTag = $_instance->getRenderedChildComponentTagName('lu7PwHW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lu7PwHW');
} else {
    $response = \Livewire\Livewire::mount('update-pemesan', []);
    $html = $response->html();
    $_instance->logRenderedChild('lu7PwHW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:update-pemesan>
                <?php else: ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('store-pesanan', [])->html();
} elseif ($_instance->childHasBeenRendered('OMEJwFo')) {
    $componentId = $_instance->getRenderedChildComponentId('OMEJwFo');
    $componentTag = $_instance->getRenderedChildComponentTagName('OMEJwFo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OMEJwFo');
} else {
    $response = \Livewire\Livewire::mount('store-pesanan', []);
    $html = $response->html();
    $_instance->logRenderedChild('OMEJwFo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:store-pesanan>
                <?php endif; ?>
            </div>
            <div style="position:fixed;left:82%; top:50%;" class="col-md-5">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('details', [])->html();
} elseif ($_instance->childHasBeenRendered('XNf64Yf')) {
    $componentId = $_instance->getRenderedChildComponentId('XNf64Yf');
    $componentTag = $_instance->getRenderedChildComponentTagName('XNf64Yf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XNf64Yf');
} else {
    $response = \Livewire\Livewire::mount('details', []);
    $html = $response->html();
    $_instance->logRenderedChild('XNf64Yf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:details>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col">
                <select wire:model="filter" name="" id="" class="form-control form-control-sm w-auto">
                    <option value="5">5</option>
                    <option value="10">10</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
            </div>
            <div class="col">
                <input wire:model="search" class="form-control" placeholder="search" type="text">
            </div>
        </div>
        <br>
        <div style="overflow-x:auto;" class="">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama_Pemesan</th>
                        <th>Alamat_Pemesan</th>
                        <th>No_Hp_Pemesan</th>
                        <th>Created At</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pemesans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pemesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($pemesan->nama_pemesan); ?></td>
                        <td><?php echo e($pemesan->alamat_pemesan); ?></td>
                        <td><?php echo e($pemesan->no_hp_pemesan); ?></td>
                        <th><?php echo e($pemesan->created_at); ?></th>
                        <td>
                            <button wire:click="getPemesan(<?php echo e($pemesan->id); ?>)" class="btn btn-warning btn-sm">Edit</button>
                            <button wire:click="destroy(<?php echo e($pemesan->id); ?>)" class="btn btn-danger btn-sm">Delete</button>
                            <button wire:click="order(<?php echo e($pemesan->id); ?>)" class="btn btn-primary btn-sm">Order</button>
                            <button wire:mousemove="detail(<?php echo e($pemesan->id); ?>)" class="btn btn-success btn-sm">lihat Pemayaran</button>
                        </tr> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($pemesans->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\catatanku3\resources\views/livewire/home-index.blade.php ENDPATH**/ ?>