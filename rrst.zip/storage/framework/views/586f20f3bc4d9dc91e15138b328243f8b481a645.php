<div>
    <?php if($detail_orders): ?>
    <div class="col-md-5">
    <table class="table table-bordered table-dark">
        <thead>
            <tr>
                <th> Rp.<?php echo e(number_format($detail_orders->total_belanja,2)); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>Uang Masuk : <?php echo e(date('d-M-Y', strtotime($p->created_at))); ?> : Rp.<?php echo e(number_format($p->nominal,2)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>Sisa : Rp.<?php echo e(number_format($sisa,2)); ?></td>
            </tr>
        </tbody>
    </table>
    </div>
    <?php else: ?>
    <div class="text-light bg-dark col-md-5">
        <h1 class="text-center">?</h1>
    </div>
    <?php endif; ?>
   
</div>
<?php /**PATH C:\xampp\htdocs\catatanku3\resources\views/livewire/details.blade.php ENDPATH**/ ?>