<div>
    <input wire:model="id_pemesan" type="text">
    <table class="table table-bordered">
        <thead>
            <tr>
                <td>Nama Pemesan</td>
                <td>Discount</td>
                <td>Nama Kurir</td>
                <td>Ongkir</td>
                <td>Total Belanja</td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($detail_orders->id_pemesan); ?></td>
            </tr>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\catatanku3\resources\views/livewire/detail-order.blade.php ENDPATH**/ ?>