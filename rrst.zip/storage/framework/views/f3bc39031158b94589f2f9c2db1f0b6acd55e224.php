<div>
    <div class="row">
        <div class="col-md-4">
            <input wire:model="no_hp" class="form-control" type="number" placeholder="masukan nomor hp anda tanpa pemisah">
            <br>
        </div>
        <div class="col-md-12" style="overflow-x:auto;">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Pemesan</th>
                        <th>Alamat Pemesan</th>
                        <th>No HP Pemesan</th>
                        <th>Created At</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pemesans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pemesan->nama_pemesan); ?></td>
                        <td><?php echo e($pemesan->alamat_pemesan); ?></td>
                        <td><?php echo e($pemesan->no_hp_pemesan); ?></td>
                        <td><?php echo e(date('d-M-Y', strtotime($pemesan->created_at))); ?></td>
                        <td>
                            <button wire:click="lihat_pesanan(<?php echo e($pemesan->id); ?>)" class="btn btn-primary btn-sm text-center">Lihat Pesanan</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-12" style="overflow-x:auto;">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pengunjung-order-index', [])->html();
} elseif ($_instance->childHasBeenRendered('sCMhPXV')) {
    $componentId = $_instance->getRenderedChildComponentId('sCMhPXV');
    $componentTag = $_instance->getRenderedChildComponentTagName('sCMhPXV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sCMhPXV');
} else {
    $response = \Livewire\Livewire::mount('pengunjung-order-index', []);
    $html = $response->html();
    $_instance->logRenderedChild('sCMhPXV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:pengunjung-order-index>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\catatanku3\resources\views/livewire/pengunjung-index.blade.php ENDPATH**/ ?>