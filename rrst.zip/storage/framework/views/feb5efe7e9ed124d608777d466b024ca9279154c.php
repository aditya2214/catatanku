<div>
<!-- <input type="text" wire:model="id_pem"> -->
    <div class="row">
        
        <div class="col-md-4">
            <?php if($getid): ?>
                <form style="margin:10px;" wire:submit.prevent="UpdateOrder">
                    <input wire:model="id_order" type="hidden">
                    <!-- <div class="form-group">
                        <input wire:model="brand" type="text" placeholder="Brand" class="form-control">
                    </div> -->
                    <div class="form-group">
                        <select wire:model="brand" name="brand" class="form-control">
                        <option selected="1" value="1" >Select</option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->nama_brand); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input wire:model="nama_produk" type="text" placeholder="Nama Produk" class="form-control">
                    </div>
                    <div class="form-group">
                        <input wire:model="sub_produk" type="text" placeholder="Sub Produk" class="form-control">
                    </div>
                    <div class="form-group">
                        <select wire:model="ukuran" name="ukuran" class="form-control">
                        <option selected="1" value="1" >Select</option>
                            <?php $__currentLoopData = $ukurans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ukuran->id); ?>"><?php echo e($ukuran->nama_ukuran); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="form-row">
                            <div class="col">
                                <input wire:model="harga_produk" type="number" placeholder="Harga Produuk" class="form-control">
                            </div>
                            <div class="col">
                                <input wire:model="jumlah_beli" type="number" placeholder="Jumlah Beli" class="form-control">
                            </div>
                        </div>
                    </div>
                    
                    <!-- <div class="form-group">
                        <input wire:model="ukuran" type="text" placeholder="Ukuran" class="form-control">
                    </div> -->
                    <button class="btn btn-success btn-sm">Simpan</button>
                </form>
                    <button style="position:relative;left:25%;top:-38px;" wire:click="batal" class="btn btn-danger btn-sm">Batal</button>
            <?php else: ?>
                <?php if($detail_orders == null): ?>
                <form style="margin:10px;" wire:submit.prevent="StoreOrder">
                    <input wire:model="id_pemesan" type="hidden">
                    <!-- <div class="form-group">
                        <input wire:model="brand" type="text" placeholder="Brand" class="form-control">
                    </div> -->
                    <div class="form-group">
                        <select wire:model="brand" name="brand" class="form-control">
                        <option selected="1" value="1" >Select</option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->nama_brand); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input wire:model="nama_produk" type="text" placeholder="Nama Produk" class="form-control">
                    </div>
                    <div class="form-group">
                        <input wire:model="sub_produk" type="text" placeholder="Sub Produk" class="form-control">
                    </div>
                    <div class="form-group">
                        <select wire:model="ukuran" name="ukuran" class="form-control">
                        <option selected="1" value="1" >Select</option>
                            <?php $__currentLoopData = $ukurans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ukuran->id); ?>"><?php echo e($ukuran->nama_ukuran); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <div class="form-row">
                            <div class="col">
                                <input wire:model="harga_produk" type="number" placeholder="Harga Produuk" class="form-control">
                            </div>
                            <div class="col">
                                <input wire:model="jumlah_beli" type="number" placeholder="Jumlah Beli" class="form-control">
                            </div>
                        </div>
                    </div>
                    
                    <!-- <div class="form-group">
                        <input wire:model="ukuran" type="text" placeholder="Ukuran" class="form-control">
                    </div> -->
                    <button class="btn btn-success btn-sm">Simpan</button>
                </form>
                <?php else: ?>

                <?php endif; ?>
            <?php endif; ?>
        </div>
        
        <?php if($detail_orders): ?>
        <div class="col-md-4">
        
        </div>
        <div class="col-md-4 ">
            <table class="table table-bordered table-dark text-center">
                <thead>
                    <tr>
                        <th>Rp.<?php echo e(number_format($detail_orders->total_belanja,2)); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(date('d-M-Y', strtotime($p->created_at))); ?> : Rp.<?php echo e(number_format($p->nominal,2)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>Sisa : Rp.<?php echo e(number_format($sisa,2)); ?></td>
                    </tr>
                </tbody>
            </table>
            <?php if($sisa == 0): ?>

            <?php else: ?>
            <br>
            <form wire:submit.prevent="Pay">
            <input wire:model="nominal" class="form-control" type="text">
            <br>
            <button style="position:relative; left:80%" class="btn btn-success">Pay</button>
            </form>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <?php endif; ?>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-12" style="overflow-x:auto;">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Brand</th>
                        <th>Nama Produk</th>
                        <th>Sub Produk</th>
                        <th>Harga Produk</th>
                        <th>Jumlah Beli</th>
                        <th>Total Belanja</th>
                        <th>Ukuran</th>
                        <?php if($detail_orders == null): ?>
                        <th>Aksi</th>
                        <?php else: ?>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->brand_relation->nama_brand); ?></td>
                        <td><?php echo e($order->nama_produk); ?></td>
                        <td><?php echo e($order->sub_produk); ?></td>
                        <td><?php echo e($order->ukuran_relation->nama_ukuran); ?></td>
                        <td><?php echo e($order->harga_produk); ?></td>
                        <td><?php echo e($order->jumlah_beli); ?></td>
                        <td><?php echo e($order->total_belanja); ?></td>
                        <?php if($detail_orders == null): ?>
                        <td>
                            <button wire:click="getid(<?php echo e($order->id); ?>)" class="btn btn-warning btn-sm">Edit</button>
                            <button wire:click="getorder(<?php echo e($order->id); ?>)" class="btn btn-danger btn-sm">Delete</button> 
                        </td>
                        <?php else: ?>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr style="background-color:black; color:white">
                        <td colspan="6">Total</td>
                        <td colspan="2"><?php echo e($total_belanja); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
    <?php if($detail_orders == null): ?>
    <div class="row">
        <div class="col-md-12" style="overflow-x:auto;">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <td class="text-center">    
                            <input wire:model="discount" id="discount" style="width:50%;" type="number" placeholder="Discount" class="form-control">
                        </td>
                        <td>
                            <input readonly value="<?php echo e($hasil_discount); ?>" id="hasil_discount" type="text" style="width:100%;" placeholder="Hasil Discount" class="form-control">
                        </td>
                        <td>
                            <a href="https://rajaongkir.com/m" target="_blank" class="btn btn-success btn-sm" rel="noopener noreferrer">Cek Ongkir</a>
                        </td>
                        <td>
                            <input wire:model="nama_ongkir" type="text" placeholder="Nama Kurir" class="form-control">
                        </td>
                        <td>
                            <input wire:model="ongkir" type="number" style="width:100%;" placeholder="Ongkir" class="form-control">
                        </td>
                        <td>
                            <input readonly value="<?php echo e($hasil_discongkir); ?>" type="text" style="width:100%;" placeholder="Total Akhir" class="form-control">
                        </td>
                        <td colspan="2" class="text-center">
                            <button wire:click="StoreDetailOrder(<?php echo e($id_pemesan); ?>)" class="btn btn-success btn-sm">Simpan</button>
                        </td>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
    <?php else: ?>
    <div class="row">
        <div class="col-md-12" style="overflow-x:auto;">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <td><?php echo e($total_belanja); ?></td>
                        <td class="text-center"> - </td>
                        <td> <?php echo e($detail_orders->discount); ?>% </td>
                        <td class="text-center"> + </td>
                        <td><?php echo e($detail_orders->ongkir); ?></td>
                        <td class="text-center"> = </td>
                        <td><?php echo e($detail_orders->total_belanja); ?></td>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
     <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\catatanku3\resources\views/livewire/order-index.blade.php ENDPATH**/ ?>