<div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Brand</th>
                <th>Nama Produk</th>
                <th>Sub Produk</th>
                <TH>Ukuran</TH>
                <th>Harga Produk</th>
                <th>Jumlah Beli</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->brand_relation->nama_brand); ?></td>
                <td><?php echo e($order->nama_produk); ?></td>
                <td><?php echo e($order->sub_produk); ?></td>
                <td><?php echo e($order->ukuran_relation->nama_ukuran); ?></td>
                <td>Rp.<?php echo e(number_format($order->harga_produk)); ?></td>
                <td><?php echo e($order->jumlah_beli); ?></td>     
                <td>Rp.<?php echo e(number_format($order->total_belanja)); ?></td>     
          </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <?php if($detail_orders == null): ?>

        <?php else: ?>
        <tfoot>
            <tr>
            <th>HARGA ASLI : Rp.<?php echo e(number_format($total_belanja)); ?></th>
            <th class="text-center"> - </th>
            <th>DISCOUNT : <?php echo e($detail_orders->discount); ?>% </th>
            <th class="text-center"> + </th>
            <th>ONGKIR : Rp.<?php echo e(number_format($detail_orders->ongkir)); ?></th>
            <th class="text-center"> = </th>
            <th>GRAND TOTAL : Rp.<?php echo e(number_format($detail_orders->total_belanja)); ?></th>
            </tr>
        </tfoot>
        <?php endif; ?>
    </table>
    <table class="table table-bordered">
        <tbody>
            <?php $__currentLoopData = $pay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>Pembayaran</td> 
                <td>Rp.<?php echo e(number_format($p->nominal)); ?> : <?php echo e(date('d-M-Y', strtotime($p->created_at))); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <th>Sisa : Rp.<?php echo e(number_format($sisa)); ?></th>
            </tr>
        </tfoot>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\catatanku3\resources\views/livewire/pengunjung-order-index.blade.php ENDPATH**/ ?>