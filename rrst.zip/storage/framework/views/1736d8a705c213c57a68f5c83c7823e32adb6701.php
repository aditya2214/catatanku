

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Tamu</div>

                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pengunjung-index', [])->html();
} elseif ($_instance->childHasBeenRendered('k97ahcO')) {
    $componentId = $_instance->getRenderedChildComponentId('k97ahcO');
    $componentTag = $_instance->getRenderedChildComponentTagName('k97ahcO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('k97ahcO');
} else {
    $response = \Livewire\Livewire::mount('pengunjung-index', []);
    $html = $response->html();
    $_instance->logRenderedChild('k97ahcO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:pengunjung-index>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\catatanku3\resources\views/tamu.blade.php ENDPATH**/ ?>