<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pay extends Model
{
    //

    protected $table = "cicilan";
    protected $guarded = [];
}
