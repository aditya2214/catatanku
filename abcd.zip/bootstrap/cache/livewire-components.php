<?php return array (
  'details' => 'App\\Http\\Livewire\\Details',
  'home-index' => 'App\\Http\\Livewire\\HomeIndex',
  'order-index' => 'App\\Http\\Livewire\\OrderIndex',
  'pengunjung-index' => 'App\\Http\\Livewire\\PengunjungIndex',
  'pengunjung-order-index' => 'App\\Http\\Livewire\\PengunjungOrderIndex',
  'report' => 'App\\Http\\Livewire\\Report',
  'store-pesanan' => 'App\\Http\\Livewire\\StorePesanan',
  'update-pemesan' => 'App\\Http\\Livewire\\UpdatePemesan',
);